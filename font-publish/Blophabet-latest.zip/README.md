# blophabet ver 1.0.0 説明書

## このフォントについて

英数記号を8つに区切った正方形だけで表したフォントです。  
Format: Truetype  
License: SIL Open Font License 1.1 (https://openfontlicense.org)
収録文字: 0123456789abcdefghijklmnopqrstuvwxyz!?,./\()

## 使用方法

同包されている「blophabet.ttf」を端末に適切な方法でインストールして下さい。

## 注意事項

「blophabet」を使用し発生した機械・ソフトウェアの故障、誤動作、誤出力などに関して製作者は一切の責任を負わないものとします。  
ご不明な点がございましたら、Twitterまでご連絡下さい。

## フォント製作者

©2022 かえる  
Twitter: @kaeru2193 (https://twitter.com/kaeru2193)