【Càgit Regular 説明書】

<このフォントについて>
Ziphilさん (https://twitter.com/Ziphil)のシャレイア語で使われる文字のセリフ体風フォントです。

Format: Truetype

License: SIL Open Font License 1.1 (https://openfontlicense.org)

収録文字: sztdkgfvpbcqxjlrnmyhaeiouâêîôûàèìòùáéí0123456789.,!?'ʻ-…«»“”


<使用方法>
同包されている「cagit-regular.ttf」を端末に適切な方法でインストールして下さい。


<注意事項>
「Càgit Regular」を使用し発生した機械・ソフトウェアの故障、誤動作、誤出力などに関して制作者は一切の責任を負わないものとします。  
ご不明な点がございましたら、制作者のX(Twitter)までご連絡下さい。


<フォント制作者>
X(Twitter): @kaeru2193 (https://twitter.com/kaeru2193)
サイト: https://kaeru2193.net

© 2024 kaeru2193