# Bosval 説明書

## このフォントについて
Ziphil (https://ziphil.com) さんの製作している『シャレイア語』で用いられる『シャレイア文字』のドットフォントです。
Format: Truetype
License: SIL Open Font License 1.1 (https://openfontlicense.org)
最終更新日: 2024/07/06


## 使用方法
同包されているttfフォントを端末に適切な方法でインストールして下さい。


## 収録文字
sztdkgfvpbcqxjlrnmyhaeiouâêîôûàèìòùáéí0123456789.,!?'ʻ-—…:«»“”


## 注意事項
「Bosval」を使用し発生した機械・ソフトウェアの故障、誤動作、誤出力などに関して製作者は一切の責任を負わないものとします。  
ご不明な点がございましたら、製作者のX(Twitter)までご連絡下さい。


## フォント製作者
©2024 かえる (https://kaeru2193.net)
X(Twitter): @kaeru2193 (https://twitter.com/kaeru2193)